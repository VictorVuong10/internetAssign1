function restart() {
    
    document.getElementById('restartForm').sumbit;
}