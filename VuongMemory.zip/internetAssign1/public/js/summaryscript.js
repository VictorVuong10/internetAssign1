function restart() {
    
    document.getElementById('restartForm').sumbit;
}

function submitScore() {
    //possible name preproccessing
    document.getElementById('nameform').sumbit;
}